import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../../_helpers/must-match.validator';
import {LoginService} from '../../service/login.service';
import { ActivatedRoute,Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userdata: any = {};
    registerForm: FormGroup;
    submitted = false;
    constructor(
      private myService: LoginService,
      private formBuilder: FormBuilder,private router: Router) { }

   ngOnInit() {
        this.registerForm = this.formBuilder.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]],
        });
    }
    get f() { return this.registerForm.controls; }

    // https://reqres.in/api/login
    // use this api for login
    // Request Params : { "email": "eve.holt@reqres.in", "password": "cityslicka" }
    

     onSubmit() {
        this.submitted = true;
  // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
        
        this.myService.login(this.userdata).subscribe((res:any) => {
          sessionStorage.setItem('token', res.token);
            if( res['token']){
            this.router.navigate(['dashboard']);
            }
      });
      
    }
   
}
