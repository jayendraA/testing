import { TestBed } from '@angular/core/testing';

import { TabletableService } from './dashboard.service';

describe('TabletableService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TabletableService = TestBed.get(TabletableService);
    expect(service).toBeTruthy();
  });
});
