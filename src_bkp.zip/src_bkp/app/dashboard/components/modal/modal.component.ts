import { Component, OnInit, Inject,Input   } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogData } from '../../DialogData';
import { MustMatch } from '../../../auth/_helpers/must-match.validator' ;
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import {DashboardComponent} from '../dashboard/dashboard.component';
@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {
  

  users = {};
  registerForm: FormGroup;
  submitted=false;
  userdata:any;
  constructor(
    public dialogRef: MatDialogRef<ModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private formBuilder: FormBuilder,
    // private dashboard:DashboardComponent
    ) {
      this.userdata=data['userdata'];
      this.users=this.data['user_record'];
      
          }

  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
        name: ['', [Validators.required]],
        username: ['', [Validators.required]],
        website: ['', [Validators.required]],
    });
}
get f() { return this.registerForm.controls; }

 onSubmit() {
        this.submitted = true;
  // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
      //  let index = this.userdata.findIndex(x => x['id'] == this.users['id']);
        // this.userdata[index]= this.users;
        this.onNoClick();
    }

}
