import { Component, OnInit,Inject } from '@angular/core';
import {DashboardService} from '../../service/dashboard.service'; 
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { ModalComponent } from '../modal/modal.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(public dashboard_service:DashboardService,public dialog: MatDialog) { }
  animal: string;
  name: string;

  userdata:any;
  // public query : string;
  public customerData : any;
  ngOnInit() {
    this.dashboard_service.users_data().subscribe((res:any) => {
      // this.userdata=JSON.parse(localStorage.getItem('userdata'));
          this.userdata=res;
        });
  }
  openDialog(userid): void {
    let user_record = this.userdata.find(x => x['id'] == userid);
    const dialogRef = this.dialog.open(ModalComponent, {
      // width: '250px',
      data: {user_record: user_record,userdata:this.userdata}
    }); 

    dialogRef.afterClosed().subscribe(result => {
      this.animal = result;
    });
  }
}
