// DialogData.ts

export interface DialogData {
    userdata: {};
    
  }