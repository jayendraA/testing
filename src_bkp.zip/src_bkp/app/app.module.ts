import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import{LayoutModule} from './login-layout/layout.module';
import {LayoutsModule} from './form-layout/layouts.module';
import {AuthGuard} from './auth.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    // GrdFilterPipe,
  ],
  imports: [
    BrowserModule,
   LayoutModule,
   HttpClientModule,
   LayoutsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
  ],
  providers: [
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
