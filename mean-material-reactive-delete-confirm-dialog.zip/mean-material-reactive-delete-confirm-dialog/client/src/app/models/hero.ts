export class Hero {
  _id?: string;
  name?: string;
}