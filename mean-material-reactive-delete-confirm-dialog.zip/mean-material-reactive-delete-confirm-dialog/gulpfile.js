require("ts-node").register({
  project: false,
  disableWarnings: true
});
require("./gulpfile.ts");