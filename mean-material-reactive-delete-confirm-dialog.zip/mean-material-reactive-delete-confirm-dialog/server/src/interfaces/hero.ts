export interface Hero {
  name?: string;
}